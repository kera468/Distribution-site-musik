import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";

export default function UploadSong() {
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [file, setFile] = useState(null);
  const [cover, setCover] = useState(null);

  const handleUpload = async () => {
    if (!title || !artist || !file || !cover) return alert("Fyll i alla fält");

    const formData = new FormData();
    formData.append("title", title);
    formData.append("artist", artist);
    formData.append("file", file);
    formData.append("cover", cover);

    const res = await fetch("https://your-api-url.onrender.com/api/upload", {
      method: "POST",
      body: formData,
    });

    if (res.ok) {
      alert("Låt uppladdad!");
      setTitle("");
      setArtist("");
      setFile(null);
      setCover(null);
    } else {
      alert("Fel vid uppladdning");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-xl shadow-xl">
        <CardContent className="space-y-6 p-6">
          <h1 className="text-2xl font-bold text-center">🎵 Ladda upp din låt</h1>

          <div>
            <Label className="mb-1 block">Titel</Label>
            <Input
              placeholder="Titel"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div>
            <Label className="mb-1 block">Artistnamn</Label>
            <Input
              placeholder="Artistnamn"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
            />
          </div>

          <div>
            <Label className="mb-1 block">Ljudfil (MP3/WAV)</Label>
            <Input
              type="file"
              accept="audio/*"
              onChange={(e) => setFile(e.target.files[0])}
            />
          </div>

          <div>
            <Label className="mb-1 block">Omslag (JPG/PNG)</Label>
            <Input
              type="file"
              accept="image/*"
              onChange={(e) => setCover(e.target.files[0])}
            />
          </div>

          <Button onClick={handleUpload} className="w-full">Ladda upp</Button>
        </CardContent>
      </Card>
    </div>
  );
}
