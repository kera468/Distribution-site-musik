import express from 'express';
import multer from 'multer';
import cors from 'cors';
import mongoose from 'mongoose';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

mongoose.connect('mongodb://localhost:27017/distribution', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Song = mongoose.model('Song', {
  title: String,
  artist: String,
  audioPath: String,
  coverPath: String,
  uploadedAt: { type: Date, default: Date.now }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

app.post('/api/upload', upload.fields([{ name: 'file' }, { name: 'cover' }]), async (req, res) => {
  try {
    const { title, artist } = req.body;
    const audioPath = req.files.file[0].path;
    const coverPath = req.files.cover[0].path;

    const song = new Song({ title, artist, audioPath, coverPath });
    await song.save();

    res.status(200).json({ message: 'Uppladdad!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Fel vid uppladdning' });
  }
});

app.listen(PORT, () => {
  console.log(`Servern körs på http://localhost:${PORT}`);
});
